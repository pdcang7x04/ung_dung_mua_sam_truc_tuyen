import { FlatList, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addItemToCart, appSlice } from '../redux/Reducer'
import AppProductCart from '../commons/AppProductCart';

const useAppDispatcher = () => useDispatch();
const useAppSelector = useSelector;


const Cart = () => {
  const dispatch = useAppDispatcher();
  const appState = useAppSelector((state) => state.authen);

  console.log(appState.cart);
  return (
    <View style={{alignItems: 'center', justifyContent: 'center'}}>
      <FlatList
        data={appState.cart}
        keyExtractor={item => item._id}
        renderItem={({item}) => <AppProductCart item={item}/>    }
      />
    </View>
  )
}

export default Cart

const styles = StyleSheet.create({})