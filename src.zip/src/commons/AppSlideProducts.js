import { Image, Pressable, StyleSheet, Text, View } from 'react-native'
import React from 'react'

const AppSlideProducts = () => {
  return (
    <View>
    </View>
  )
}

export default AppSlideProducts

const styles = StyleSheet.create({})